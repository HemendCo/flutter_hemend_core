import 'dart:convert';

import 'package:hemend/debug/error_handler.dart';
import 'package:hive/hive.dart';

part 'exercise_model.g.dart';

@HiveType(typeId: 201)
class ExerciseModel extends HiveObject {
  @HiveField(0)
  final int quantity;
  @HiveField(1)
  final ExerciseExecutionType type;
  @HiveField(2)
  final String name;
  @HiveField(3)
  final double kcal;
  @HiveField(4)
  final double duration;
  @HiveField(5)
  final String description;
  ExerciseModel({
    required this.quantity,
    required this.type,
    required this.name,
    required this.kcal,
    required this.duration,
    required this.description,
  });

  ExerciseModel copyWith({
    int? quantity,
    ExerciseExecutionType? type,
    String? name,
    double? kcal,
    double? duration,
    String? description,
  }) {
    return ExerciseModel(
      quantity: quantity ?? this.quantity,
      type: type ?? this.type,
      name: name ?? this.name,
      kcal: kcal ?? this.kcal,
      duration: duration ?? this.duration,
      description: description ?? this.description,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'quantity': quantity,
      'type': type.toMap(),
      'name': name,
      'kcal': kcal,
      'duration': duration,
      'description': description,
    };
  }

  factory ExerciseModel.fromMap(Map<String, dynamic> map) {
    return ExerciseModel(
      quantity: map['quantity']?.toInt() ?? 0,
      type: ExerciseExecutionType.fromMap(map['type']),
      name: map['name'] ?? '',
      kcal: map['kcal']?.toDouble() ?? 0.0,
      duration: map['duration']?.toDouble() ?? 0.0,
      description: map['description'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory ExerciseModel.fromJson(String source) => ExerciseModel.fromMap(json.decode(source));

  @override
  String toString() {
    return 'ExerciseModel(quantity: $quantity, type: $type, name: $name, kcal: $kcal, duration: $duration, description: $description)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is ExerciseModel &&
        other.quantity == quantity &&
        other.type == type &&
        other.name == name &&
        other.kcal == kcal &&
        other.duration == duration &&
        other.description == description;
  }

  @override
  int get hashCode {
    return quantity.hashCode ^ type.hashCode ^ name.hashCode ^ kcal.hashCode ^ duration.hashCode ^ description.hashCode;
  }
}

@HiveType(typeId: 210)
enum ExerciseExecutionType {
  @HiveField(0)
  unit,
  @HiveField(1)
  time;

  Map<String, dynamic> toMap() {
    switch (this) {
      case ExerciseExecutionType.unit:
        return {
          'type': 'unit',
        };
      case ExerciseExecutionType.time:
        return {
          'type': 'time',
        };
    }
  }

  static ExerciseExecutionType fromMap(Map<String, dynamic> map) {
    switch (map['type']) {
      case 'unit':
        return ExerciseExecutionType.unit;
      case 'time':
        return ExerciseExecutionType.time;
    }
    throw ErrorHandler('cannot convert $map to ExerciseExecutionType');
  }
}
