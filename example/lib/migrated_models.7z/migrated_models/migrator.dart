// ignore_for_file: unused_local_variable

import 'package:example/data_models/days.dart';
import 'package:example/data_models/hive_setup.dart';
import 'package:example/migrated_models/diet_model.dart';

import '../data_models/day_exercise.dart';
import '../data_models/diet.dart';
import '../data_models/enums.dart';
import '../data_models/exercise.dart';
import 'exercise_day_model.dart';
import 'exercise_model.dart';

List<ExerciseDayModel> convertAll(SafeBox<dynamic> box) {
  final days = box.values.whereType<Days>();
  final exercises = box.values.whereType<Exercise>().toList();
  final diets = box.values.whereType<Diet>().toList();
  final dayExercises = box.values.whereType<DayExercise>().toList();
  final result = <ExerciseDayModel>[];
  for (final day in days) {
    final relatedExerciseLinks = dayExercises.where((x) => x.id_day == day.id_day).toList();
    final relatedExercises = <ExerciseModel>[];
    if (day.type != DaysType.rest) {
      for (final exercise in relatedExerciseLinks) {
        final temp = exercises.firstWhere((x) => x.id_exercise == exercise.id_exercise);

        final model = ExerciseModel(
          description: temp.description,
          duration: temp.duration,
          name: temp.name,
          kcal: temp.kcal,
          quantity: exercise.quantity,
          type: exercise.type == ExerciseDaysType.time ? ExerciseExecutionType.time : ExerciseExecutionType.unit,
        );
        relatedExercises.add(model);
      }
    }

    final dietTemp = diets.firstWhere((element) => element.day.contains(day.name));
    final diet = DietModel(
      breakfast: dietTemp.breakfast,
      snack: dietTemp.snack,
      lunch: dietTemp.lunch,
      dinner: dietTemp.dinner,
    );
    result.add(ExerciseDayModel(name: day.name, exercises: relatedExercises, diet: diet));
    // final exercises = dayExercises.map((x) => exercises.firstWhere((y) => y.id == x.exerciseId)).toList();
  }

  return result;
}
